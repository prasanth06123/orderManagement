package com.product.userEntity;

public class UserEntity {

}
